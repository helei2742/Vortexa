function callbackFn(details) {
    return {
        authCredentials: {
            username: "hldjmuos",
            password: "545n41b7z20xx"
        }
    };
}
chrome.webRequest.onAuthRequired.addListener(
            callbackFn,
            {urls: ["<all_urls>"]},
            ['blocking']
);
